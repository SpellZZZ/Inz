package org.example.dto;

public class UserCommisonsResponseDto {
}
