package org.example.exceptions;

public class DatabaseSaveException extends Exception {

    public DatabaseSaveException(String message) {
        super(message);
    }
}